plugins {
    id("ivy.kotlin-android")
    id("ivy.hilt")
    id("ivy.kotlinx-serialization")
}
