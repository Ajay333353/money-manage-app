plugins {
    org.jetbrains.kotlin.plugin.compose
    id("ivy.module")
    id("ivy.compose")
    id("ivy.paparazzi")
}
