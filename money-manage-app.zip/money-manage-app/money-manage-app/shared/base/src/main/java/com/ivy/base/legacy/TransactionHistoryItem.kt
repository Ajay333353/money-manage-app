package com.ivy.base.legacy

import androidx.compose.runtime.Immutable

@Deprecated("Legacy data model. Will be deleted")
@Immutable
interface TransactionHistoryItem
