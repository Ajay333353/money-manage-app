package com.ivy.data.model

import androidx.annotation.Keep

@Keep
enum class LoanType {
    BORROW, LEND
}
