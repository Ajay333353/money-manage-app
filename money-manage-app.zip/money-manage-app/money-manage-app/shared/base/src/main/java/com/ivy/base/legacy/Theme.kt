package com.ivy.base.legacy

import androidx.compose.runtime.Immutable

@Deprecated("Old design system. Use `:ivy-design` and Material3")
@Immutable
enum class Theme {
    LIGHT, DARK, AUTO, AMOLED_DARK
}
