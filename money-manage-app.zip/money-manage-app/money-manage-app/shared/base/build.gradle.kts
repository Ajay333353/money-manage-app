plugins {
    id("ivy.feature")
}

android {
    namespace = "com.ivy.base"
}
