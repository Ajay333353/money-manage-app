package com.ivy.data.backup

data class CSVRow(
    val index: Int,
    val content: List<String>
)
