plugins {
    id("ivy.script")
}

dependencies {
    api(libs.bundles.ktor)
}
