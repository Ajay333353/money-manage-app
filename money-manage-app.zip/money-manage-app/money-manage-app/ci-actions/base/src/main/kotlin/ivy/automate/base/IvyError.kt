package ivy.automate.base

class IvyError(msg: String) : Exception(msg)
