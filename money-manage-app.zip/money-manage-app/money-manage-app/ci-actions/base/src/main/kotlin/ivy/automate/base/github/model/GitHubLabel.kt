package ivy.automate.base.github.model

data class GitHubLabel(
    val name: GitHubLabelName,
)
