package ivy.automate.base.github.model

data class GitHubUser(
    val username: GitHubUsername
)
