package com.ivy.loans.loan

import androidx.compose.runtime.Immutable

@Immutable
enum class LoanTab {
    PENDING, COMPLETED
}