package com.ivy.loans.loan

internal object Constants {
    const val SWIPE_HORIZONTAL_THRESHOLD = 200
}
