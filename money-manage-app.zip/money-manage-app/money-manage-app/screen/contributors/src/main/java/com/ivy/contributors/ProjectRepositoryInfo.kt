package com.ivy.contributors

data class ProjectRepositoryInfo(
    val forks: String,
    val stars: String,
    val url: String
)
