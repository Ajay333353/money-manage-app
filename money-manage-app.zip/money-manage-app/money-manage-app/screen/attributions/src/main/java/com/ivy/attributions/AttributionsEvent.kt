package com.ivy.attributions

sealed interface AttributionsEvent
