package com.ivy.home

object Constants {
    const val SWIPE_HORIZONTAL_THRESHOLD = 200
    const val SWIPE_DOWN_THRESHOLD_OPEN_MORE_MENU = 200
}
