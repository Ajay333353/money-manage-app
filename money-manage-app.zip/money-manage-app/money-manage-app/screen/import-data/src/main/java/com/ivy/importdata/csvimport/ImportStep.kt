package com.ivy.importdata.csvimport

enum class ImportStep {
    IMPORT_FROM, INSTRUCTIONS, LOADING, RESULT
}
